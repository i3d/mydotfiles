To port themes from vim to vifm [this](http://vim.wikia.com/wiki/Xterm256_color_names_for_console_Vim) is helpful to look up colors.
