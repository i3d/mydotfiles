static const char* selbgcolor   = "#151512";
static const char* selfgcolor   = "#d8d7d1";
static const char* normbgcolor  = "#A79458";
static const char* normfgcolor  = "#d8d7d1";
static const char* urgbgcolor   = "#BB9D42";
static const char* urgfgcolor   = "#d8d7d1";
