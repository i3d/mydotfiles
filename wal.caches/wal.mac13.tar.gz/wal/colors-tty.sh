#!/bin/sh
[ "${TERM:-none}" = "linux" ] && \
    printf '%b' '\e]P0151512
                 \e]P1BB9D42
                 \e]P2A79458
                 \e]P33F5B80
                 \e]P45A718B
                 \e]P575899D
                 \e]P69BA3A8
                 \e]P7d8d7d1
                 \e]P8979692
                 \e]P9BB9D42
                 \e]PAA79458
                 \e]PB3F5B80
                 \e]PC5A718B
                 \e]PD75899D
                 \e]PE9BA3A8
                 \e]PFd8d7d1
                 \ec'
