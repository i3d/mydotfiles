const char *colorname[] = {

  /* 8 normal colors */
  [0] = "#151512", /* black   */
  [1] = "#BB9D42", /* red     */
  [2] = "#A79458", /* green   */
  [3] = "#3F5B80", /* yellow  */
  [4] = "#5A718B", /* blue    */
  [5] = "#75899D", /* magenta */
  [6] = "#9BA3A8", /* cyan    */
  [7] = "#d8d7d1", /* white   */

  /* 8 bright colors */
  [8]  = "#979692",  /* black   */
  [9]  = "#BB9D42",  /* red     */
  [10] = "#A79458", /* green   */
  [11] = "#3F5B80", /* yellow  */
  [12] = "#5A718B", /* blue    */
  [13] = "#75899D", /* magenta */
  [14] = "#9BA3A8", /* cyan    */
  [15] = "#d8d7d1", /* white   */

  /* special colors */
  [256] = "#151512", /* background */
  [257] = "#d8d7d1", /* foreground */
  [258] = "#d8d7d1",     /* cursor */
};

/* Default colors (colorname index)
 * foreground, background, cursor */
 unsigned int defaultbg = 0;
 unsigned int defaultfg = 257;
 unsigned int defaultcs = 258;
 unsigned int defaultrcs= 258;
