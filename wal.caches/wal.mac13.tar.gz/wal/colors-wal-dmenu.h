static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#d8d7d1", "#151512" },
	[SchemeSel] = { "#d8d7d1", "#BB9D42" },
	[SchemeOut] = { "#d8d7d1", "#9BA3A8" },
};
