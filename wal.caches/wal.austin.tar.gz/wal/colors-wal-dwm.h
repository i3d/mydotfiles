static const char norm_fg[] = "#94bdc4";
static const char norm_bg[] = "#07080A";
static const char norm_border[] = "#678489";

static const char sel_fg[] = "#94bdc4";
static const char sel_bg[] = "#667176";
static const char sel_border[] = "#94bdc4";

static const char urg_fg[] = "#94bdc4";
static const char urg_bg[] = "#516A72";
static const char urg_border[] = "#516A72";

static const char *colors[][3]      = {
    /*               fg           bg         border                         */
    [SchemeNorm] = { norm_fg,     norm_bg,   norm_border }, // unfocused wins
    [SchemeSel]  = { sel_fg,      sel_bg,    sel_border },  // the focused win
    [SchemeUrg] =  { urg_fg,      urg_bg,    urg_border },
};
