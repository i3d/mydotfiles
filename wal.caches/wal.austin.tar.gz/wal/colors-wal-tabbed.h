static const char* selbgcolor   = "#07080A";
static const char* selfgcolor   = "#94bdc4";
static const char* normbgcolor  = "#667176";
static const char* normfgcolor  = "#94bdc4";
static const char* urgbgcolor   = "#516A72";
static const char* urgfgcolor   = "#94bdc4";
