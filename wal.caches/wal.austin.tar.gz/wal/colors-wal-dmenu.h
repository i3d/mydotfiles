static const char *colors[SchemeLast][2] = {
	/*     fg         bg       */
	[SchemeNorm] = { "#94bdc4", "#07080A" },
	[SchemeSel] = { "#94bdc4", "#516A72" },
	[SchemeOut] = { "#94bdc4", "#3E7986" },
};
