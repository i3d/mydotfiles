#!/bin/sh
[ "${TERM:-none}" = "linux" ] && \
    printf '%b' '\e]P007080A
                 \e]P1516A72
                 \e]P2667176
                 \e]P3A36943
                 \e]P47D817E
                 \e]P5DB955F
                 \e]P63E7986
                 \e]P794bdc4
                 \e]P8678489
                 \e]P9516A72
                 \e]PA667176
                 \e]PBA36943
                 \e]PC7D817E
                 \e]PDDB955F
                 \e]PE3E7986
                 \e]PF94bdc4
                 \ec'
