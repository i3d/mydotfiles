const char *colorname[] = {

  /* 8 normal colors */
  [0] = "#07080A", /* black   */
  [1] = "#516A72", /* red     */
  [2] = "#667176", /* green   */
  [3] = "#A36943", /* yellow  */
  [4] = "#7D817E", /* blue    */
  [5] = "#DB955F", /* magenta */
  [6] = "#3E7986", /* cyan    */
  [7] = "#94bdc4", /* white   */

  /* 8 bright colors */
  [8]  = "#678489",  /* black   */
  [9]  = "#516A72",  /* red     */
  [10] = "#667176", /* green   */
  [11] = "#A36943", /* yellow  */
  [12] = "#7D817E", /* blue    */
  [13] = "#DB955F", /* magenta */
  [14] = "#3E7986", /* cyan    */
  [15] = "#94bdc4", /* white   */

  /* special colors */
  [256] = "#07080A", /* background */
  [257] = "#94bdc4", /* foreground */
  [258] = "#94bdc4",     /* cursor */
};

/* Default colors (colorname index)
 * foreground, background, cursor */
 unsigned int defaultbg = 0;
 unsigned int defaultfg = 257;
 unsigned int defaultcs = 258;
 unsigned int defaultrcs= 258;
